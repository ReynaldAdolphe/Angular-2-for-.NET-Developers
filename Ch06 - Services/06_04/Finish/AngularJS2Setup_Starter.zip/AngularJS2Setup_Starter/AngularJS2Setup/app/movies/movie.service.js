"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var MovieService = (function () {
    function MovieService() {
    }
    MovieService.prototype.getMovies = function () {
        return [{
                "movieId": 4,
                "movieName": "Sully",
                "movieStar": "Hanks",
                "releaseDate": "9/9/2016",
                "price": 16.00,
                "starRating": 3.5,
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMTg5NTUwNDIyOV5BMl5BanBnXkFtZTgwMjI2OTc3OTE@._V1_UX182_CR0,0,182,268_AL_.jpg"
            },
            {
                "movieId": 5,
                "movieName": "Wild Life",
                "movieStar": "Albert",
                "releaseDate": "9/9/2016",
                "price": 14.00,
                "starRating": 5.0,
                "imageUrl": "http://ia.media-imdb.com/images/M/MV5BMjA4OTE0MjAwNl5BMl5BanBnXkFtZTgwMjY4Mzg2OTE@._V1_UX182_CR0,0,182,268_AL_.jpg"
            }];
    };
    MovieService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], MovieService);
    return MovieService;
}());
exports.MovieService = MovieService;
//# sourceMappingURL=movie.service.js.map